﻿namespace MyProj
{
    /// <summary>
    /// Hello hello
    /// </summary>
    public class Class1
    {
        //todo
        //Todo
        //TODO
    }
}